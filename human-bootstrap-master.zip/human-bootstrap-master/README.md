<img src="http://beinghuman.is/public/img/color-bar-2000x3.png" />
# Human Design
### Human Bootstrap is a Node.js boilerplate

## Dependencies

This command needs to be run first if CoffeeScript is not installed on your system

* run `sudo npm install -g coffee-script`
* run `sudo npm install -g gulp`

## Setup

Install all of the dependencies necessary for the bootstrap

* run `npm install`

## Development

The following command will watch and compile Coffeescript and Stylus.

* run `gulp`

## Deployment
#### Combine and minify assets
* run `gulp build`
