require('coffee-script/register');
require('./Gulpfile.coffee');